from modules.config.config import Config
from modules.config.info import AboutResource
from modules.login.login import Login, Register
from modules.login.serviceSubscription import Subscripe, Unsubscripe
from modules.database.DB import DataBaseOpps as DB
from apscheduler.schedulers.background import BackgroundScheduler
from trello import Trello, ChatGPT
from multiprocessing import Process
import multiprocessing
from flask import Flask, request, render_template, redirect, url_for
from requests_oauthlib import OAuth1Session
import os
from dotenv import load_dotenv

load_dotenv()

api_trello = os.getenv('API_TRELLO')
api_secret = os.getenv('API_SECRET')

app = Flask(__name__)

ChatGPT = ChatGPT()
trel = Trello()


def check_board_changes():
    res = trel.has_checkboard
    # user_input = request.form.get('user_input')
    trel.check_board_changes()
    if res:
        ChatGPT.handleChatGPT("what is 2 + 2 ?")

@app.route('/')
def index():
    authorization_url = trel.get_authorize_url()
    return render_template('input.html', authorization_url=authorization_url)

@app.route('/oauth_callback', methods=['POST'])

@app.route('/oauth_callback', methods=['POST'])
def oauth_callback():
    verification_code = request.form.get('verification_code')

    if verification_code:
        trel = Trello()
        trel.aunthification_trello(verification_code)
        return redirect(url_for('index'))
    else:
        return "Verification code not provided. Authentication failed."

@app.route('/check_board_changes', methods=['POST'])
def check_board_changes():
    if trel.Oauth_token is None:
        return "Trello is not authenticated. Please authenticate first."

    p = Process(target=trel.check_board_changes)
    p.start()

    # You can now use ChatGPT to respond to board changes
    ChatGPT.handleChatGPT("What is 2 + 2?")

    return "Board changes are being checked. ChatGPT is responding."

if __name__ == '__main__':
    app.run(debug=True, threaded=True)