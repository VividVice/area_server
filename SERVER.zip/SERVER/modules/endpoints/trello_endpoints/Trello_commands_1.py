from flask import request, jsonify
from flask_restful import Resource
from sys import path
path.append('../../')
from modules.config.config import Config
from modules.utils.jsonToken import UnpackToken
from modules.database.DB import DataBaseOpps as DB
from modules.APIs.trello.TrelloWebhook import Setup, TrelloHandleHook
app = Config().GetApp()

@app.route('/trello/')
def Trello_reg_service():
    payload = UnpackToken(request.headers.get('Authorization'), True)
    if payload:
        access_token = request.args.get('access_token')
        if not access_token:
            return jsonify({"message": "No access token provided"}), 403
        user = DB.GetUser(payload["username"])
        if user:
            DB.SubcripeToService(user, "trello", {"access_token": access_token})
            Setup(user)
            return jsonify({"message": "Service added successfully."}), 200
        else:
            return jsonify({"message": "User not found"}), 401

    else:
        return jsonify({"message": "Invalid credentials"}), 403

@app.route('/trello/list')
def Trello_get_lists():
    payload = UnpackToken(request.headers.get('Authorization'), True)
    if payload:
        user = DB.GetUser(payload["username"])
        if user:
            return jsonify(user.user_services["trello"]["list_created"]), 200
        else:
            return jsonify({"message": "User not found"}), 401

    else:
        return jsonify({"message": "Invalid credentials"}), 403