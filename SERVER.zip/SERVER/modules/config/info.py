from flask import Flask, jsonify, request
from flask_restful import Resource, Api
import time

# example of service methods for info they should follow sigleton pattern
class Test:
    def get_service_info(self):
        return {
            "name": "facebook",
            "actions": [
                {
                    "name": "new_message_in_group",
                    "description": "A new message is posted in the group",
                },
                {
                    "name": "new_message_inbox",
                    "description": "A new private message is received by the user",
                },
                {
                    "name": "new_like",
                    "description": "The user gains a like from one of their messages",
                },
            ],
            "reactions": [{"name": "like_message", "description": "The user likes a message"}],
        }

def get_server_status():
    # serveces list
    services = [Test()]
    # Create the server_info dictionary
    server_info = {
        "client": {"host": request.remote_addr},
        "server": {
            "current_time": int(time.time()),
            "services": [],
        },
    }

    # Add the service to the services list
    for service in services:
        try:
            server_info["server"]["services"].append(service.get_service_info())
        except AttributeError :
            pass

    # Return the server_info dictionary as json
    return jsonify(server_info)

class AboutResource(Resource):
    def get(self):
        return get_server_status()