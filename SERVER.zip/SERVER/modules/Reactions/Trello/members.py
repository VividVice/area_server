import sys
sys.path.append('../')
from modules.APIs.trello.Trello_actions import Trello

def members(user, request_data, action_type):
    member_id = request_data['action']['memberCreator']['id']
    member_name = request_data['action']['memberCreator']['fullName']
    member_username = request_data['action']['memberCreator']['username']
    member_data = Trello.get_member_data(user, member_id)
    member_boards = Trello.get_member_boards(user, member_id)
    member_cards = Trello.get_member_cards(user, member_id)
    member_actions = Trello.get_member_actions(user, member_id)
    if action_type == 'addMemberToBoard':
        pass
    elif action_type == 'removeMemberFromBoard':
        pass
    else:
        return {'message': 'unknown action type'}, 400