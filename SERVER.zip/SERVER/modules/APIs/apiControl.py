import json

class APIController:
    def __init__(self, configuration):
        self.configuration = configuration
        self.api_instances = {
            # "spotify": SpotifyAPI(),
            # "discord": DiscordAPI(),
            # Add more API instances as needed
        }
        self.event_listeners = {}

        # Register event listeners for all APIs
        for connection in configuration["connections"]:
            source_api = connection["source_api"]
            event = connection["event"]
            target_api = connection["target_api"]
            action = connection["action"]

            if source_api in self.api_instances:
                self.api_instances[source_api].register_event_listener(
                    event, self.handle_event, target_api, action
                )

    def register_event_listener(self, event, callback):
        if event not in self.event_listeners:
            self.event_listeners[event] = []
        self.event_listeners[event].append(callback)

# open config for json file
# with open("config.json", "r") as config_file:
#     configuration = json.load(config_file)

# that's how you call it
# if __name__ == '__main__':
# controller = APIController(configuration)