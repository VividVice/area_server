from sys import path
from os import getenv
path.append('../..')
from modules.config.config import Config
from modules.database.DB import UserModel
from requests import request

class Trello():

    @staticmethod
    def create_auth_header(user:UserModel):
        header = f'Authorization: OAuth oauth_consumer_key="{getenv("API_SECRET_TRELLO")}"'
        header += f', oauth_token="{user.user_services["trello"]["access_token"]}"'
        return header

    @staticmethod
    def get_user_boards(user:UserModel):
        url = "https://api.trello.com/1/members/me/boards"
        response = request.get(url, headers=Trello.create_auth_header(user))
        return response.json()

    @staticmethod
    def get_board_data(user:UserModel, board_id):
        url = f"https://api.trello.com/1/boards/{board_id}"
        response = request.get(url, headers=Trello.create_auth_header(user))
        return response.json()

    @staticmethod
    def get_board_lists(user:UserModel, board_id):
        url = f"https://api.trello.com/1/boards/{board_id}/lists"
        response = request.get(url, headers=Trello.create_auth_header(user))
        return response.json()

    @staticmethod
    def get_board_cards(user:UserModel, board_id):
        url = f"https://api.trello.com/1/boards/{board_id}/cards"
        response = request.get(url, headers=Trello.create_auth_header(user))
        return response.json()

    @staticmethod
    def get_board_members(user:UserModel, board_id):
        url = f"https://api.trello.com/1/boards/{board_id}/members"
        response = request.get(url, headers=Trello.create_auth_header(user))
        return response.json()
    # post methods

    @staticmethod
    def post_board(user:UserModel, board_name):
        url = f"https://api.trello.com/1/boards/"
        response = request.post(url, headers=Trello.create_auth_header(user), data={"name": board_name})
        return response.json()

    @staticmethod
    def post_list(user:UserModel, board_id, list_name):
        url = f"https://api.trello.com/1/boards/{board_id}/lists"
        response = request.post(url, headers=Trello.create_auth_header(user), data={"name": list_name})
        return response.json()

    @staticmethod
    def post_card(user:UserModel, list_id, card_name):
        url = f"https://api.trello.com/1/cards"
        response = request.post(url, headers=Trello.create_auth_header(user), data={"name": card_name, "idList": list_id})
        return response.json()

    @staticmethod
    def post_comment(user:UserModel, board_id, card_id, comment):
        url = f"https://api.trello.com/1/cards/{card_id}/actions/comments"
        response = request.post(url, headers=Trello.create_auth_header(user), data={"text": comment})
        return response.json()

    @staticmethod
    def post_member(user:UserModel, board_id, member_id):
        url = f"https://api.trello.com/1/boards/{board_id}/members"
        response = request.post(url, headers=Trello.create_auth_header(user), data={"email": member_id})
        return response.json()
    # DO NOT DELETE the methdos after this line
    @staticmethod
    def get_user_id(user:UserModel):
        url = f"https://api.trello.com/1/members/me"
        response = request.get(url, headers=Trello.create_auth_header(user))
        return response.json()["id"]
    @staticmethod
    def post_webhook(user:UserModel, webhook_data):
        url = f"https://api.trello.com/1/tokens/{getenv('API_SECRET_TRELLO')}/webhooks/"
        response = request.post(url, headers=Trello.create_auth_header(user), json=webhook_data)
        return response.json()