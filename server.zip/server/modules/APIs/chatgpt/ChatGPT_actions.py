from sys import path
from os import getenv
import json
import requests
path.append('../..')
from modules.config.config import Config
from modules.database.DB import UserModel

class ChatGPT:

    @staticmethod
    def create_auth_header(user: UserModel):
        header = {
            "Content-Type": "application/json",
            "api-key": getenv("CHATGPT_API_KEY") #ba3e6534f94542cb858884cdb2f49b29
        }
        return header

    @staticmethod
    def post_message_sentiments(user: UserModel, message_content):
        url = "https://luna-aibot-demo-oai.openai.azure.com/openai/deployments/WidgetFaces/chat/completions?api-version=2023-07-01-preview"
        data = {
            "messages": [
                {"role": "user", "content": "Analyse les sentiments avec le message suivant:" + message_content},
            ],
            "max_tokens": 300,
            "temperature": 0.7,
            "frequency_penalty": 0,
            "presence_penalty": 0,
            "top_p": 0.95,
            "stop": None
        }
        response = requests.post(url, headers=ChatGPT.create_auth_header(user), data=json.dumps(data))
        return response.json()

    @staticmethod
    def post_message_categories(user: UserModel, message_content):
        url = "https://luna-aibot-demo-oai.openai.azure.com/openai/deployments/WidgetFaces/chat/completions?api-version=2023-07-01-preview"
        data = {
            "messages": [
                {"role": "user", "content": "classifie ce texte en categories avec le message suivant:" + message_content},
            ],
            "max_tokens": 300,
            "temperature": 0.7,
            "frequency_penalty": 0,
            "presence_penalty": 0,
            "top_p": 0.95,
            "stop": None
        }
        response = requests.post(url, headers=ChatGPT.create_auth_header(user), data=json.dumps(data))
        return response.json()

    @staticmethod
    def post_message_summarize(user: UserModel, message_content):
        url = "https://luna-aibot-demo-oai.openai.azure.com/openai/deployments/WidgetFaces/chat/completions?api-version=2023-07-01-preview"
        data = {
            "messages": [
                {"role": "user", "content": "fait un resumé rapide avec le message suivant:" + message_content},
            ],
            "max_tokens": 300,
            "temperature": 0.7,
            "frequency_penalty": 0,
            "presence_penalty": 0,
            "top_p": 0.95,
            "stop": None
        }
        response = requests.post(url, headers=ChatGPT.create_auth_header(user), data=json.dumps(data))
        return response.json()

    @staticmethod
    def post_message_mail(user: UserModel, message_content):
        url = "https://luna-aibot-demo-oai.openai.azure.com/openai/deployments/WidgetFaces/chat/completions?api-version=2023-07-01-preview"
        data = {
            "messages": [
                {"role": "user", "content": "fait un mail le message suivant:" + message_content},
            ],
            "max_tokens": 300,
            "temperature": 0.7,
            "frequency_penalty": 0,
            "presence_penalty": 0,
            "top_p": 0.95,
            "stop": None
        }
        response = requests.post(url, headers=ChatGPT.create_auth_header(user), data=json.dumps(data))
        return response.json()

    @staticmethod
    def extract_response_message(response_json):
        bot_response = response_json["choices"][0]["message"]["content"]
        return bot_response

# Usage Example
# Assuming you have a UserModel instance called user
# chat_gpt = ChatGPT()
# response_json = chat_gpt.post_message(user, "Hello, how are you?")
# response_message = chat_gpt.extract_response_message(response_json)
# print(response_message)
