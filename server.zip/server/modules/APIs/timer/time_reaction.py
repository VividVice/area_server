import requests

def get_current_time(city_name):
    url = f'http://worldtimeapi.org/api/timezone/{city_name}'

    try:
        response = requests.get(url)
        data = response.json()
        current_time = data['datetime']
        current_time = current_time.split('T')[1]
        print(f"L'heure actuelle à {city_name} est : {current_time}")
    except Exception as e:
        print(f"Une erreur s'est produite : {e}")
get_current_time('Europe/Paris')
