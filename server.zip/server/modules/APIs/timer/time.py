import requests
import time

def get_current_time():
    try:
        response = requests.get("http://worldtimeapi.org/api/ip")
        data = response.json()
        return data['datetime']
    except Exception as e:
        print(f"Erreur lors de la récupération de l'heure : {e}")
        return None

target_hour = 17
target_minute = 31

while True:
    current_time = time.localtime()
    print(target_hour)
    print(current_time.tm_hour)
    print(current_time.tm_min)
    print(target_minute)
    if current_time.tm_hour == target_hour and current_time.tm_min == target_minute:
        print("Hello")
        break
    time.sleep(1)