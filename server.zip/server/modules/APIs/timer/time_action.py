from os import getenv
from sys import path
path.append('../..')
from modules.database.DB import UserModel
import requests
import time
from os import getenv
from dotenv import load_dotenv


def getServiceInfo():
    return {
        "name" : "time",
        "actions" : [
            {
                "name" : "waitTime",
                "description" : "Wait for the timer",
                "params": {"hour": int, "minute": int}
            },
        ],
        "reactions" : [
            {"name": "getCurrentTime", "description": "get the current time", "params": {"continent/city": str}},
        ]
    }

# Actions
def wait_time(target_hour, target_minute):
    try:
        while True:
            response = requests.get("http://worldtimeapi.org/api/ip")
            data = response.json()
            current_hour = int(data['datetime'][11:13])
            current_minute = int(data['datetime'][14:16])

            if current_hour == target_hour and current_minute == target_minute:
                print("Hello")
                break

            time.sleep(2)
    except Exception as e:
        print(f"Erreur lors de la récupération de l'heure : {e}")

# Reactions
def get_current_time(city_name):
    url = f'http://worldtimeapi.org/api/timezone/{city_name}'

    try:
        response = requests.get(url)
        data = response.json()
        current_time = data['datetime']
        current_time = current_time.split('T')[1]
        print(f"L'heure actuelle à {city_name} est : {current_time}")
    except Exception as e:
        print(f"Une erreur s'est produite : {e}")