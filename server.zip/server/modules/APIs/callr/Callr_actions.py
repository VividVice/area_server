from sys import path
from os import getenv
import callr
path.append('../..')
from modules.config.config import Config
from modules.database.DB import UserModel
from requests import  get, post, delete

# make a obj requst that has the method get from requests

class Callr():
    @staticmethod

    def get_service_info():
        return {
            "name" : "callr",
            "actions" : [
                {
                    "name" : "call_outbound_hangup",
                    "description" : "A call is hangup",
                    "params": {}
                },
                {
                    "name" : "call_inbound_start",
                    "description" : "A call is started",
                    "params": {}
                },
                {
                    "name" : "call_outbound_start",
                    "description" : "A call is started",
                    "params": {}
                },
                {
                    "name" : "media_recording",
                    "description" : "A media is recorded",
                    "params": {}
                },
                {
                    "name" : "call_inbound_hangup",
                    "description" : "A call is hangup",
                    "params": {}
                },
                {
                    "name" : "billing_credit",
                    "description" : "A billing credit",
                    "params": {}
                },
                {
                    "name" : "send_sms",
                    "description" : "A sms is sent",
                    "params": {}
                },
                {
                    "name" : "did_assigned",
                    "description" : "A did is assigned",
                    "params": {}
                },
                {
                    "name" : "did_unassigned",
                    "description" : "A did is unassigned",
                    "params": {}
                }
            ],
            "reactions" : [
                {"name": "make_call", "description": "Make a call", "params": {"target": str, "msg": str}},
                {"name": "send_sms", "description": "Send a sms", "params": {"target": str, "msg": str}},
                {"name": "create_media", "description": "Create a media", "params": {"name": str}},
                {"name": "update_media_tts", "description": "Update a media", "params": {"id": str, "msg": str}},
                {"name": "get_list_of_medias", "description": "Get list of medias", "params": {}},
                {"name": "get_quota_status", "description": "Get quota status", "params": {}},
            ]
        }

    # Actions

    @staticmethod
    def call_outbound_hangup(user:UserModel):
        try:
            api = callr.Api(api_login, api_password)

            type = 'call.outbound_hangup'
            endpoint = 'https://2ca2-176-148-84-155.ngrok.io'
            options = None

            result = api.call('webhooks.subscribe', type, endpoint, options)
            print(result)

            return {"message": "call_outbound_hangup"}, 200
        except Exception as e:
            print(e)
            return {"message": "an error occured"}, 500

    @staticmethod
    def call_inbound_start(user:UserModel):
        try:
            api = callr.Api(api_login, api_password)


            type = 'call.inbound_start'
            endpoint = 'https://2ca2-176-148-84-155.ngrok.io'
            options = None

            result = api.call('webhooks.subscribe', type, endpoint, options)
            print(result)

            return {"message": "call_inbound_start"}, 200
        except Exception as e:
            print(e)
            return {"message": "an error occured"}, 500

    @staticmethod
    def call_outbound_start(user:UserModel):
        try:
            api = callr.Api(api_login, api_password)

            type = 'call.outbound_start'
            endpoint = 'https://2ca2-176-148-84-155.ngrok.io'
            options = None

            result = api.call('webhooks.subscribe', type, endpoint, options)
            print(result)

            return {"message": "call_outbound_start"}, 200
        except Exception as e:
            print(e)
            return {"message": "an error occured"}, 500

    @staticmethod
    def media_recording(user:UserModel):
        try:
            api = callr.Api(api_login, api_password)

            type = 'media.recording.new'
            endpoint = 'https://2ca2-176-148-84-155.ngrok.io'
            options = None

            result = api.call('webhooks.subscribe', type, endpoint, options)
            print(result)

            return {"message": "media_recording"}, 200
        except Exception as e:
            print(e)
            return {"message": "an error occured"}, 500

    @staticmethod
    def call_inbound_hangup(user:UserModel):
        try:
            api = callr.Api(api_login, api_password)

            type = 'call.inbound_hangup'
            endpoint = 'https://2ca2-176-148-84-155.ngrok.io'
            options = None

            result = api.call('webhooks.subscribe', type, endpoint, options)
            print(result)

            return {"message": "call_inbound_hangup"}, 200
        except Exception as e:
            print(e)
            return {"message": "an error occured"}, 500

    @staticmethod
    def billing_credit(user:UserModel):
        try:
            api = callr.Api(api_login, api_password)

            type = 'billing.credit'
            endpoint = 'https://2ca2-176-148-84-155.ngrok.io'
            options = None

            result = api.call('webhooks.subscribe', type, endpoint, options)
            print(result)

            return {"message": "billing_credit"}, 200
        except Exception as e:
            print(e)
            return {"message": "an error occured"}, 500

    @staticmethod
    def send_sms(user:UserModel):
        try:
            api = callr.Api(api_login, api_password)

            type = 'sms.mo'
            endpoint = 'https://2ca2-176-148-84-155.ngrok.io'
            options = None

            result = api.call('webhooks.subscribe', type, endpoint, options)
            print(result)

            return {"message": "send_sms"}, 200
        except Exception as e:
            print(e)
            return {"message": "an error occured"}, 500

    @staticmethod
    def did_assigned(user:UserModel):
        try:
            api = callr.Api(api_login, api_password)

            type = 'did.assigned'
            endpoint = 'https://2ca2-176-148-84-155.ngrok.io'
            options = None

            result = api.call('webhooks.subscribe', type, endpoint, options)
            print(result)

            return {"message": "did_assigned"}, 200
        except Exception as e:
            print(e)
            return {"message": "an error occured"}, 500

    @staticmethod
    def did_unassigned(user:UserModel):
        try:
            api = callr.Api(api_login, api_password)

            type = 'did.unassigned'
            endpoint = 'https://2ca2-176-148-84-155.ngrok.io'
            options = None

            result = api.call('webhooks.subscribe', type, endpoint, options)
            print(result)

            return {"message": "did_unassigned"}, 200
        except Exception as e:
            print(e)
            return {"message": "an error occured"}, 500

    # Reactions

    @staticmethod
    def make_call(user:UserModel, phone_number):
        try:
            api = callr.Api(api_login, api_password)

            target = {
                'number': phone_number,
                'timeout': 30
            }

            messages = [131, 132, 'TTS|TTS_EN-GB_SERENA|Hello world! how are you ? I hope you enjoy this call. good bye.']

            options = {
                'cdr_field': 'userData',
                'cli': 'BLOCKED',
                'loop': 2
            }

            result = api.call('calls.broadcast_1', target, messages, options)
            print(result)
        except Exception as e:
            print(e)
            return {"message": "an error occured"}, 500

    @staticmethod
    def send_sms(user:UserModel, phone_number, message):
        try:
            api = callr.Api(api_login, api_password)

            target = phone_number
            sender = "AREACRAFT"
            message = message

            if sender == '':
                sender = 'SMS'

            result = api.call('sms.send', sender, target, message, None)
            print(result)
        except Exception as e:
            print(e)
            return {"message": "an error occured"}, 500

    @staticmethod
    def create_media(user:UserModel):
        try:
            api = callr.Api(api_login, api_password)

            result = api.call('media/library.create', 'media_name')
            print(result)
        except Exception as e:
            print(e)
            return {"message": "an error occured"}, 500

    @staticmethod
    def update_media_tts(user:UserModel, media_id, text):
        try:
            api = callr.Api(api_login, api_password)

            # example media_id = 6869741

            media_id = media_id
            text_to_speech = text

            result = api.call('media/tts.set_content', media_id, text_to_speech, 'TTS_EN-GB_SERENA', None)
            print(result)
        except Exception as e:
            print(e)
            return {"message": "an error occured"}, 500

    @staticmethod
    def get_list_of_medias(user:UserModel):
        try:
            api = callr.Api(api_login, api_password)

            result = api.call('media/library.get_list', None)
            print(result)
        except Exception as e:
            print(e)
            return {"message": "an error occured"}, 500

    @staticmethod
    def get_quota_status(user:UserModel):
        try:
            api = callr.Api(api_login, api_password)

            result = api.call('did/store.get_quota_status')
            print(result)
        except Exception as e:
            print(e)
            return {"message": "an error occured"}, 500
