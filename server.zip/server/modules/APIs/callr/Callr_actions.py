from os import getenv
from sys import path
import callr
path.append('../..')
from modules.database.DB import UserModel

def getServiceInfo():
    return {
        "name" : "callr",
        "actions" : [
            {
                "name" : "callOutboundHangup",
                "description" : "A call is hangup",
                "params": {}
            },
            {
                "name" : "callInboundStart",
                "description" : "A call is started",
                "params": {}
            },
            {
                "name" : "callOutboundStart",
                "description" : "A call is started",
                "params": {}
            },
            {
                "name" : "mediaRecording",
                "description" : "A media is recorded",
                "params": {}
            },
            {
                "name" : "callInboundHangup",
                "description" : "A call is hangup",
                "params": {}
            },
            {
                "name" : "billingCredit",
                "description" : "A billing credit",
                "params": {}
            },
            {
                "name" : "sendSms",
                "description" : "A sms is sent",
                "params": {}
            },
            {
                "name" : "didAssigned",
                "description" : "A did is assigned",
                "params": {}
            },
            {
                "name" : "didUnassigned",
                "description" : "A did is unassigned",
                "params": {}
            }
        ],
        "reactions" : [
            {"name": "makeCall", "description": "Make a call", "params": {"target": str, "msg": str}},
            {"name": "sendSms", "description": "Send a sms", "params": {"target": str, "msg": str}},
            {"name": "createMedia", "description": "Create a media", "params": {"name": str}},
            {"name": "updateMediaTts", "description": "Update a media", "params": {"id": str, "msg": str}},
            {"name": "getListOfMedias", "description": "Get list of medias", "params": {}},
            {"name": "getQuotaStatus", "description": "Get quota status", "params": {}},
        ]
    }

# Actions

def create_webhook(user:UserModel, type, endpoint, options):
    try:
        user_services = user.user_services["callr"]
        api_login = user_services["username"]
        api_password = user_services["password"]
        print(api_login, api_password)
        api = callr.Api(api_login, api_password)
        result = api.call('webhooks.create', type, endpoint, options)
        print(result)
    except Exception as e:
        print(e)
        return {"message": "anErrorOccured"}, 500


# def create_call_outbound_hangup(user:UserModel):
#     try:
#         user_services = user.user_services["callr"]
#         api_login = user_services["username"]
#         api_password = user_services["password"]

#         print(api_login, api_password)

#         api = callr.Api(api_login, api_password)

#         type = 'call.outbound_hangup'
#         endpoint = f'{getenv("SERVER_URL")}/callr/webhook/?user_name={user.username}'
#         options = None

#         result = api.call('webhooks.subscribe', type, endpoint, options)
#         print(result)

#         return {"message": "callOutboundHangup"}, 200
#     except Exception as e:
#         print(e)
#         return {"message": "anErrorOccured"}, 500


# def create_call_inbound_start(user:UserModel):
#     try:
#         user_services = user.user_services["callr"]
#         api_login = user_services["username"]
#         api_password = user_services["password"]

#         print(api_login, api_password)

#         api = callr.Api(api_login, api_password)

#         type = 'call.inbound_start'
#         endpoint = f'{getenv("SERVER_URL")}/callr/webhook/?user_name={user.username}'
#         options = None

#         result = api.call('webhooks.subscribe', type, endpoint, options)
#         print(result)

#         return {"message": "callInboundStart"}, 200
#     except Exception as e:
#         print(e)
#         return {"message": "anErrorOccured"}, 500


# def create_call_outbound_start(user:UserModel):
#     try:
#         user_services = user.user_services["callr"]
#         api_login = user_services["username"]
#         api_password = user_services["password"]

#         print(api_login, api_password)

#         api = callr.Api(api_login, api_password)

#         type = 'call.outbound_start'
#         endpoint = f'{getenv("SERVER_URL")}/callr/webhook/?user_name={user.username}'
#         options = None

#         result = api.call('webhooks.subscribe', type, endpoint, options)
#         print(result)

#         return {"message": "callOutboundStart"}, 200
#     except Exception as e:
#         print(e)
#         return {"message": "anErrorOccured"}, 500


# def create_media_recording(user:UserModel):
#     try:
#         user_services = user.user_services["callr"]
#         api_login = user_services["username"]
#         api_password = user_services["password"]

#         print(api_login, api_password)

#         api = callr.Api(api_login, api_password)

#         type = 'media.recording.new'
#         endpoint = f'{getenv("SERVER_URL")}/callr/webhook/?user_name={user.username}'
#         options = None

#         result = api.call('webhooks.subscribe', type, endpoint, options)
#         print(result)

#         return {"message": "mediaRecording"}, 200
#     except Exception as e:
#         print(e)
#         return {"message": "anErrorOccured"}, 500


# def create_call_inbound_hangup(user:UserModel):
#     try:
#         user_services = user.user_services["callr"]
#         api_login = user_services["username"]
#         api_password = user_services["password"]

#         print(api_login, api_password)

#         api = callr.Api(api_login, api_password)

#         type = 'call.inbound_hangup'
#         endpoint = f'{getenv("SERVER_URL")}/callr/webhook/?user_name={user.username}'
#         options = None

#         result = api.call('webhooks.subscribe', type, endpoint, options)
#         print(result)

#         return {"message": "callInboundHangup"}, 200
#     except Exception as e:
#         print(e)
#         return {"message": "anErrorOccured"}, 500


# def create_billing_credit(user:UserModel):
#     try:
#         user_services = user.user_services["callr"]
#         api_login = user_services["username"]
#         api_password = user_services["password"]

#         print(api_login, api_password)

#         api = callr.Api(api_login, api_password)

#         type = 'billing.credit'
#         endpoint = f'{getenv("SERVER_URL")}/callr/webhook/?user_name={user.username}'
#         options = None

#         result = api.call('webhooks.subscribe', type, endpoint, options)
#         print(result)

#         return {"message": "billingCredit"}, 200
#     except Exception as e:
#         print(e)
#         return {"message": "anErrorOccured"}, 500


# def create_send_sms(user:UserModel):
#     try:
#         user_services = user.user_services["callr"]
#         api_login = user_services["username"]
#         api_password = user_services["password"]

#         print(api_login, api_password)

#         api = callr.Api(api_login, api_password)

#         type = 'sms.mo'
#         endpoint = f'{getenv("SERVER_URL")}/callr/webhook/?user_name={user.username}'
#         options = None

#         result = api.call('webhooks.subscribe', type, endpoint, options)
#         print(result)

#         return {"message": "sendSms"}, 200
#     except Exception as e:
#         print(e)
#         return {"message": "anErrorOccured"}, 500


# def create_did_assigned(user:UserModel):
#     try:
#         user_services = user.user_services["callr"]
#         api_login = user_services["username"]
#         api_password = user_services["password"]

#         print(api_login, api_password)

#         api = callr.Api(api_login, api_password)

#         type = 'did.assigned'
#         endpoint = f'{getenv("SERVER_URL")}/callr/webhook/?user_name={user.username}'
#         options = None

#         result = api.call('webhooks.subscribe', type, endpoint, options)
#         print(result)

#         return {"message": "didAssigned"}, 200
#     except Exception as e:
#         print(e)
#         return {"message": "anErrorOccured"}, 500


# def create_did_unassigned(user:UserModel):
#     try:
#         user_services = user.user_services["callr"]
#         api_login = user_services["username"]
#         api_password = user_services["password"]

#         print(api_login, api_password)

#         api = callr.Api(api_login, api_password)

#         type = 'did.unassigned'
#         endpoint = f'{getenv("SERVER_URL")}/callr/webhook/?user_name={user.username}'
#         options = None

#         result = api.call('webhooks.subscribe', type, endpoint, options)
#         print(result)

#         return {"message": "didUnassigned"}, 200
#     except Exception as e:
#         print(e)
#         return {"message": "anErrorOccured"}, 500

# Reactions

def make_call(user:UserModel, target, msg):
    try:
        user_services = user.user_services["callr"]
        api_login = user_services["username"]
        api_password = user_services["password"]

        print(api_login, api_password)

        api = callr.Api(api_login, api_password)

        target = {
            'number': target,
            'timeout': 30
        }

        if msg == '':
            msg = 'Hello world! how are you ? I hope you enjoy this call. good bye.'

        messages = [131, 132, 'TTS|TTS_EN-GB_SERENA|' + msg]

        options = {
            'cdr_field': 'userData',
            'cli': 'BLOCKED',
            'loop': 2
        }

        result = api.call('calls.broadcast_1', target, messages, options)
        print(result)
    except Exception as e:
        print(e)
        return {"message": "anErrorOccured"}, 500


def send_sms(user:UserModel, target, msg, sender):
    try:
        user_services = user.user_services["callr"]
        api_login = user_services["username"]
        api_password = user_services["password"]

        print(api_login, api_password)

        api = callr.Api(api_login, api_password)

        if sender == '':
            sender = 'SMS'

        result = api.call('sms.send', sender, target, msg, None)
        print(result)
    except Exception as e:
        print(e)
        return {"message": "anErrorOccured"}, 500


def create_media(user:UserModel, name):
    try:
        user_services = user.user_services["callr"]
        api_login = user_services["username"]
        api_password = user_services["password"]

        print(api_login, api_password)

        api = callr.Api(api_login, api_password)

        result = api.call('media/library.create', name)
        print(result)
    except Exception as e:
        print(e)
        return {"message": "anErrorOccured"}, 500


def update_media_tts(user:UserModel, id, msg):
    try:
        user_services = user.user_services["callr"]
        api_login = user_services["username"]
        api_password = user_services["password"]

        print(api_login, api_password)

        api = callr.Api(api_login, api_password)

        # example media_id = 6869741

        result = api.call('media/tts.set_content', id, msg, 'TTS_EN-GB_SERENA', None)
        print(result)
    except Exception as e:
        print(e)
        return {"message": "anErrorOccured"}, 500


def get_list_of_medias(user:UserModel):
    try:
        user_services = user.user_services["callr"]
        api_login = user_services["username"]
        api_password = user_services["password"]

        print(api_login, api_password)

        api = callr.Api(api_login, api_password)

        result = api.call('media/library.get_list', None)
        print(result)
    except Exception as e:
        print(e)
        return {"message": "anErrorOccured"}, 500


def get_quota_status(user:UserModel):
    try:
        user_services = user.user_services["callr"]
        api_login = user_services["username"]
        api_password = user_services["password"]

        print(api_login, api_password)

        api = callr.Api(api_login, api_password)

        result = api.call('did/store.get_quota_status')
        print(result)
    except Exception as e:
        print(e)
        return {"message": "anErrorOccured"}, 500
