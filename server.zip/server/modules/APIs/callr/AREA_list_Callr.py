action_list = [
    {
        "name" : "callOutboundHangup",
        "description" : "A call is hangup",
        "params": {}
    },
    {
        "name" : "callInboundStart",
        "description" : "A call is started",
        "params": {}
    },
    {
        "name" : "callOutboundStart",
        "description" : "A call is started",
        "params": {}
    },
    {
        "name" : "mediaRecording",
        "description" : "A media is recorded",
        "params": {}
    },
    {
        "name" : "callInboundHangup",
        "description" : "A call is hangup",
        "params": {}
    },
    {
        "name" : "billingCredit",
        "description" : "A billing credit",
        "params": {}
    },
    {
        "name" : "sendSms",
        "description" : "A sms is sent",
        "params": {}
    },
    {
        "name" : "didAssigned",
        "description" : "A did is assigned",
        "params": {}
    },
    {
        "name" : "didUnassigned",
        "description" : "A did is unassigned",
        "params": {}
    }
]

reactions_list = [
    {
        "name": "makeCall",
		"description": "Make a call",
        "function_name": "make_call",
		"params": {"target": str, "msg": str}
    },
    {
        "name": "sendSms",
        "description": "Send a sms",
        "function_name": "send_sms",
        "params": {"target": str, "msg": str}
    },
    {
        "name": "createMedia",
		"description": "Create a media",
        "function_name": "create_media",
		"params": {"name": str}
    },
    {
        "name": "updateMediaTts",
		"description": "Update a media",
        "function_name": "update_media_tts",
		"params": {"id": str, "msg": str}
    },
    {
        "name": "getListOfMedias",
		"description": "Get list of medias",
        "function_name": "get_list_of_medias",
		"params": {}
    },
    {
        "name": "getQuotaStatus",
		"description": "Get quota status",
        "function_name": "get_quota_status",
        "params": {}
    }
]

