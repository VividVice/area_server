import requests
from os import getenv
from dotenv import load_dotenv

load_dotenv()

api_key = getenv('WEATHER_API')

def get_current_weather(city):
    try:
        response = requests.get(f'http://api.weatherstack.com/current?access_key={api_key}&query={city}')
        data = response.json()

        if 'current' in data and 'weather_descriptions' in data['current']:
            current_weather = data['current']['weather_descriptions'][0]
            return f"Le temps actuel à {city} est : {current_weather}"
        else:
            return f"Aucune information météorologique disponible pour {city}"
    except Exception as e:
        return f"Erreur lors de la récupération des informations météorologiques : {e}"
city = 'London'
result = get_current_weather(city)
print(result)
