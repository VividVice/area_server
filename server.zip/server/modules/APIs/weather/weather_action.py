import requests
import time
from os import getenv
from dotenv import load_dotenv

load_dotenv()

api_key = getenv('WEATHER_API')

city = 'Paris'

while True:
    try:
        response = requests.get(f'http://api.weatherstack.com/current?access_key={api_key}&query={city}')
        data = response.json()

        if 'current' in data and 'weather_descriptions' in data['current']:
            current_weather = data['current']['weather_descriptions'][0]
            print(f"Le temps actuel à {city} est : {current_weather}")

            is_night = 'nuit' in current_weather.lower()
            if is_night:
                print("Il fait nuit")
            else:
                print("Il ne fait pas nuit")

    except Exception as e:
        print(f"Erreur lors de la récupération des informations météorologiques : {e}")

    time.sleep(60)