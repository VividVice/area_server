from os import getenv
from sys import path
path.append('../..')
from modules.database.DB import UserModel
import requests
import time
from os import getenv
from dotenv import load_dotenv


def getServiceInfo():
    return {
        "name" : "weather",
        "actions" : [
            {
                "name" : "getWeather",
                "description" : "Get the current weather",
                "params": {}
            },
        ],
        "reactions" : [
            {"name": "getCurrentWeather", "description": "get the current weather", "params": {"city": str}},
        ]
    }

# Actions
def get_weather():
    load_dotenv()
    city = 'Paris'
    api_key = getenv('WEATHER_API')

    while True:
        try:
            response = requests.get(f'http://api.weatherstack.com/current?access_key={api_key}&query={city}')
            data = response.json()

            if 'current' in data and 'weather_descriptions' in data['current']:
                current_weather = data['current']['weather_descriptions'][0]
                print(f"Le temps actuel à {city} est : {current_weather}")

                is_sunny = 'sunny' in current_weather.lower()
                if is_sunny:
                    print("Il fait soleil")
                else:
                    print("Il ne fait pas soleil")

        except Exception as e:
            print(f"Erreur lors de la récupération des informations météorologiques : {e}")

        time.sleep(60)

# Reactions
def get_current_weather(city):
    load_dotenv()
    api_key = getenv('WEATHER_API')
    try:
        response = requests.get(f'http://api.weatherstack.com/current?access_key={api_key}&query={city}')
        data = response.json()

        if 'current' in data and 'weather_descriptions' in data['current']:
            current_weather = data['current']['weather_descriptions'][0]
            print(f"Le temps actuel à {city} est : {current_weather}")
        else:
            return f"Aucune information météorologique disponible pour {city}"
    except Exception as e:
        return f"Erreur lors de la récupération des informations météorologiques : {e}"