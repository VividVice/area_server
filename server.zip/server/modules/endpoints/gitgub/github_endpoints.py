from flask import request
from flask_restful import Resource, reqparse
from sys import path
path.append('../../')
from modules.utils.jsonToken import UnpackToken
from modules.database.DB import DataBaseOpps as DB
from modules.APIs.github.OauthGithub import GithubAuth
from modules.APIs.github.github_action import get_github_email

# /github/?code={code} header: Authorization: Bearer {token}
class Github_Access(Resource):
    def post(self):
        # print("Github_Access")
        authorization_header = request.headers.get('Authorization')
        parser = reqparse.RequestParser()
        parser.add_argument('code', type=str, required=True)
        args = parser.parse_args()
        if not authorization_header:
            return {"message": "No Authorization header provided"}, 403
        payload = UnpackToken(authorization_header, True)
        if payload:
            user = DB.GetUser(payload["username"])
            if user:
                GithubAuth().get_authificated(user, args['code'])
                return {"message": "Service creation pending successfully."}, 200

    def options(self):
        # say everything is allowed on this route and make the browser happy and send the get request
        return {'Allow': 'PUT,GET,POST'}, 200, \
                {'Access-Control-Allow-Origin': '*', \
                'Access-Control-Allow-Methods': 'PUT,GET,POST, OPTIONS', \
                'Access-Control-Allow-Headers': 'Content-Type, Authorization'}

    def head(self):
        """Checks if the user has the service
        Returns:
            200: if the user has the service
            400: if the user doesn't have the service
            403: if the request is not authenticated"""
        authorization_header = request.headers.get('Authorization')
        if not authorization_header:
            return {}, 403
        payload = UnpackToken(authorization_header, True)
        user = DB.GetUser(payload["username"])
        if not user or user.user_services["trello"] == False:
            return {}, 400
        return {}, 200

# THIS IS SERVER SIDE
class GithubCallback(Resource):
    def post(self):
        username = request.args.get('username')
        user = DB.GetUser(username)
        if not user:
            return {"message": "User not found"}, 401
        parser = reqparse.RequestParser()
        parser.add_argument('access_token', type=str, required=True)
        args = parser.parse_args()
        if not args['access_token']:
            return {"message": "No access token provided"}, 403
        if DB.SubcripeToService(user, "github", {"access_token": args['access_token'], "Areas" : []}) == False:
            return {"message": "DB error"}, 502
        email = get_github_email(args['access_token'])
        DB.AddUserOauth(user, email) # so that he can use github for login
        return {"message": "Service added successfully."}, 200

    def options(self):
        # say everything is allowed on this route and make the browser happy and send the get request
        return {'Allow': 'PUT,GET,POST'}, 200, \
                {'Access-Control-Allow-Origin': '*', \
                'Access-Control-Allow-Methods': 'PUT,GET,POST, OPTIONS', \
                'Access-Control-Allow-Headers': 'Content-Type, Authorization'}

    def head(self):
        return {"message": "Github callback"}, 200