import sys
sys.path.append('../')
from modules.APIs.trello.Trello_actions import *
# using a name of fuction given as a string call it and pass the params to it (if any) you must unpack the params first, params are
# given as args to the function so use kwargs(the equviant to args_list in C) to unpack them
# example:user = DB.GetUser(payload["username"])
# FuncInvoker('my_function', user=user, **reaction_dict["params"])
list_of_actions = {
    "trello" : [
        {"post_board" : post_board}, # post_board(**kwargs)
        {"post_list" : post_list}, # post_list(**kwargs)
        {"post_card" : post_card}, # post_card(**kwargs)
        {"post_member" : post_member}, # post_member(**kwargs)
    ] }

def FuncInvoker(service_name, func_name, user, **kwargs):
    # get the function to call
    try :
        func = list(filter(lambda x: list(x.keys())[0] == func_name, list_of_actions[service_name]))[0][func_name]
    except Exception:
        raise Exception(f"Function {func_name} not found in service {service_name}")
    return func(user=user, **kwargs)