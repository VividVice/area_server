import sys
# using a name of fuction given as a string call it and pass the params to it (if any) you must unpack the params first, params are
# given as args to the function so use kwargs(the equviant to args_list in C) to unpack them
# example:user = DB.GetUser(payload["username"])
# FuncInvoker('my_function', user=user, **reaction_dict["params"])
def FuncInvoker(func_name, **kwargs):
    func = getattr(sys.modules[__name__], func_name)
    return func(**kwargs)