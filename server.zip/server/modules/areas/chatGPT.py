import requests
import json

def handleChatGPT():
    url = "https://luna-aibot-demo-oai.openai.azure.com/openai/deployments/WidgetFaces/chat/completions?api-version=2023-07-01-preview"

    data = {
        "messages": [
            {"role": "user", "content": "Réponds à cette question :" + userMessage},
        ],
        "max_tokens": 300,
        "temperature": 0.7,
        "frequency_penalty": 0,
        "presence_penalty": 0,
        "top_p": 0.95,
        "stop": None
    }

    headers = {
        "Content-Type": "application/json",
        "api-key": "ba3e6534f94542cb858884cdb2f49b29"
    }

    response = requests.post(url, headers=headers, data=json.dumps(data))
    response_data = response.json()
    botResponse = response_data["choices"][0]["message"]["content"]
    print(botResponse)