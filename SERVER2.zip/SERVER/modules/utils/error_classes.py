
class UnknowService(Exception):
    def __init__(self, service_name):
        self.service_name = service_name

    def __str__(self):
        return f"Unknow service: {self.service_name}"

class FailedExecution(Exception):
    def __init__(self, service_name):
        self.service_name = service_name

    def __str__(self):
        return f"Failed to execute service: {self.service_name}"

class UnknowUser(Exception):
    """Raise when a user is not found in the database."""
    def __init__(self, username) -> None:
        self.username = username

    def __str__(self) -> str:
        return f'User {self.username} is not found in the database.'