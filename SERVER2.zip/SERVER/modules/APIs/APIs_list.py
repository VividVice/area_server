import sys
sys.path.append("..")
from modules.APIs.service_supcription.StrategySubcrpition import SubscriptionStrategy, UnSubscriptionStrategy
from modules.APIs.service_supcription.TestStrategy import TestSubcrpibeStrategy, TestUnSubcrpibeStrategy
from modules.APIs.trello.TrelloSubStrat import TrelloSubStrat, TrelloUnSubStrat
from modules.APIs.callr.Callr_strategy import CallrSubStrategy, CallrUnsubStrategy
""" Key = service name , value =
    {
        "subscribe" : subscribe strategy,
        "unsubscribe" : unsubscribe strategy
    }
"""
list_api = {
    "testSub" : {
        "subscribe" : TestSubcrpibeStrategy(),
        "unsubscribe" : TestUnSubcrpibeStrategy()
    },
    "trello" : {
        "subscribe" : TrelloSubStrat(),
        "unsubscribe" : TrelloUnSubStrat()
    },
    "github" : {
        "subscribe" : SubscriptionStrategy(),
        "unsubscribe" : UnSubscriptionStrategy()
    },
    "callr" : {
        "subscribe" : CallrSubStrategy(),
        "unsubscribe" : CallrUnsubStrategy()
    }
}