import sys

sys.path.append('../../../')
from modules.database.DB import UserModel
from modules.database.DB import DataBaseOpps as DB
from modules.APIs.service_supcription.StrategySubcrpition import SubscriptionStrategy, UnSubscriptionStrategy

class CallrSubStrategy(SubscriptionStrategy):
    def execute(self, user:UserModel, service_args: dict):
        if not service_args.get('return_url'):
            raise Exception("No return url provided")
        # check if the user is already subscribed to the service
        if user.user_services["callr"] != None and  user.user_services["callr"] != False :
            print(user.user_services["callr"])
            return {"message": "Service already added."}, 400
        auth_url = "https://google.com"
        return {"auth_url": auth_url}, 200

class CallrUnsubStrategy(UnSubscriptionStrategy):
    def execute(self, user:UserModel, service_args: dict):
        if user.user_services["callr"] == None or user.user_services["callr"] == False:
            return {"message": "Not sub to service."}, 400
        DB.UnSubcripeToService(user, "callr")
        return {"message": "Service removed successfully."}, 200
