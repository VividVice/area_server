from os import getenv
from sys import path
path.append('../')
from flask import request
from modules.database.DB import DataBaseOpps as DB, UserModel
from modules.APIs.trello.Trello_actions import Trello
from modules.config.config import Config
from modules.Reactions.Trello.cards import cards
from modules.Reactions.Trello.lists import lists
from modules.Reactions.Trello.boards import boards
from modules.Reactions.Trello.members import members

app = Config().GetApp()

def get_endpoint() -> str:
    return 'trello/webhook'

# setup all webhooks for all users
def SetupAll() -> None:
    sub_users = DB.getSubServiceUsers('trello')
    for user in sub_users:
        user_id = Trello.get_user_id(user)
        webhook_data = {
            'description': f'webhook for user {user_id}',
            'callbackURL': f'{getenv("SERVER_URL")}/{get_endpoint()}/?user_name={user.username}',
            'idModel': user_id,
            'active': True,
            'type': 'all'
        }
        Trello.post_webhook(user, webhook_data)

# setup webhook for a specific user
def Setup(User:UserModel):
    user_id = Trello.get_user_id(User)
    webhook_data = {
        'description': f'webhook for user {user_id}',
        'callbackURL': f'{getenv("SERVER_URL")}/{get_endpoint()}/?user_name={User.username}',
        'idModel': user_id,
        'active': True,
        # it should be do creating/updating/deleting a board, list, card, member, etc...
        'type': ['createCard', 'updateCard', 'deleteCard', 'createList', 'updateList', 'deleteList', 'createBoard', 'updateBoard', 'deleteBoard', 'createMember', 'updateMember', 'deleteMember']
    }
    Trello.post_webhook(User, webhook_data)

def DeleteAll() -> None:
    sub_users = DB.getSubServiceUsers('trello')
    for user in sub_users:
        user_id = Trello.get_user_id(user)
        webhooks = Trello.get_webhooks(user)
        for webhook in webhooks:
            Trello.delete_webhook(user, webhook['id'])

def Delete(User:UserModel) -> None:
    user_id = Trello.get_user_id(User)
    webhooks = Trello.get_webhooks(User)
    for webhook in webhooks:
        Trello.delete_webhook(User, webhook['id'])

@app.route(f'/{get_endpoint()}/', methods=['POST', 'HEAD'])
def TrelloHandleHook():
    """Handle the webhook for trello."""
    if request.method == 'HEAD':
        return {'message': 'success'}, 200
    user_name = request.args.get('user_name')
    print("the user name is", user_name)
    user = DB.GetUser(user_name)
    if user:
        request_data = dict(request.json)
        action_type = request_data['action']['type']
        if "Card" in action_type:
            cards(user, request_data, action_type)
        elif "List" in action_type:
            lists(user, request_data, action_type)
        elif "Board" in action_type:
            boards(user, request_data, action_type)
        elif "Member" in action_type:
            members(user, request_data, action_type)
        return {'message': 'success'}, 200
    else:
        return {'message': 'user not found'}, 400