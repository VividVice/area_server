from os import getenv
from sys import path
path.append('../..')
from modules.utils.jsonToken import createToken
from modules.config.config import app_name

def singleton(cls):
    """A singleton decorator."""
    instances = {}
    def getinstance():
        if cls not in instances:
            instances[cls] = cls()
        return instances[cls]
    return getinstance

@singleton
class GitHubAuth:
    def __init__(self) -> None:
        self.Auth_url = "https://github.com/login/oauth/authorize"
        self.scope = "user"
        self.name = app_name
        self.expiration = "never"
        self.response_type = "token"
        self.key = getenv('GITHUB_API_SECRET')

    def get_authorize_url(self, username, return_url):
        state = createToken(username, False)
        url = f"{self.Auth_url}?scope={self.scope}&expiration={self.expiration}&name={self.name}"
        url += f"&response_type={self.response_type}&key={self.key}&state={state}"
        url += f"&return_url={return_url}"
        return url