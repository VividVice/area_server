from flask_sqlalchemy import SQLAlchemy
import sys
from sqlalchemy_json import MutableDict
sys.path.append('../')
from modules.config.config import Config
from modules.utils.error_classes import UnknowService, UnknowUser
from sqlalchemy_utils import database_exists
from os import getenv

config = Config()
db:SQLAlchemy = config.GetDb()
app = config.GetApp()

class UserModel(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(30), nullable=False)
    password = db.Column(db.String(30), nullable=False)
    # add the api services that the user has subscribed to
    user_services = db.Column(MutableDict.as_mutable(db.JSON), nullable=False, default={})
    is_admin = db.Column(db.Boolean, nullable=False, default=False)

    def __init__(self, username, password):
        self.username = username
        self.password = password

    def __repr__(self) -> str:
        return f'<User {self.username} With Id {self.id} : {self.services}>'

    def serialize(self):
        return {
            'id': self.id,
            'username': self.username,
            'password': self.password
        }

class ServiceModel(db.Model):
    __tablename__ = 'services'
    id = db.Column(db.Integer, primary_key=True)
    names = db.Column(db.String(30), nullable=False)
    users = db.relationship('UserModel', secondary='user_services', backref=db.backref('services', lazy='dynamic'))

    users_service = db.Table('user_services', db.Model.metadata,
        db.Column('user_id', db.Integer, db.ForeignKey('users.id')),
        db.Column('service_id', db.Integer, db.ForeignKey('services.id'))
    )

class DataBaseOpps():
    @staticmethod
    def CreateDb() -> None:
        from modules.APIs.APIs_list import list_api # do not move this import to the top of the file or dire things will happen
        """Create the database only if it does not exist."""
        if not database_exists(getenv('DATABASE_URI')):
            with app.app_context():
                db.create_all()
                for service_name in list_api.keys():
                    service = ServiceModel(names=service_name)
                    db.session.add(service)
                # create the admin user
                admin = UserModel(username=getenv('ADMIN_USERNAME'), password=getenv('ADMIN_PASSWORD'))
                admin.is_admin = True
                db.session.add(admin)
                db.session.commit()

    @staticmethod
    def GetUser(username) -> UserModel :
        """Get a user from the database. Will return None if the user does not exist."""
        return UserModel.query.filter_by(username=username).first()

    @staticmethod
    def AddUser(username, password) -> UserModel :
        from modules.APIs.APIs_list import list_api # do not move this import to the top of the file or dire things will happen
        """Add a user to the database. Sets the currently supported services to False(not enabled).
        Will return False if the user already exists.
        Will return the user if it was added successfully."""
        if not DataBaseOpps.GetUser(username):
            JsonServices = {}
            for service_name in list_api.keys():
                JsonServices[service_name] = False # put whatever afterwards aka any type of data
            user = UserModel(username=username, password=password)
            user.user_services = JsonServices
            db.session.add(user)
            db.session.commit()
            return user
        return False

    @staticmethod
    def DeleteUser(user:UserModel) -> bool:
        """Delete a user from the database. Will return False if the user does not exist.
        Will return True if the user was deleted successfully.
        in the future it should do unsubscription from all services first"""
        if user:
            # UnsubFromAllServices(user)
            db.session.delete(user)
            db.session.commit()
            return True
        return False


    @staticmethod
    def SubcripeToService(user:UserModel, service:str, value:any) -> bool:
        """Add a service subscription to the user. Will return False if the user already has the service.
        If the user does not exist, it will raise an UnknowUser exception."""
        if user:
            service_obj = ServiceModel.query.filter_by(names=service).first()
            if not service_obj:
                raise UnknowService(service)
            # user.services is a json object that contains all the services that the user has subscribed to check if the service is not false it means that the user has subscribed to it
            if service in user.user_services and user.user_services[service] != False:
                return False
            print("the value is", value)
            services = user.user_services
            services[service] = value # can be anything
            user.user_services = services
            # add the user to the service
            service_obj.users.append(user)
            db.session.commit()
            return True
        raise UnknowUser(user)

    @staticmethod
    def IsAdmin(user:UserModel) -> bool: # may be useless but we will see
        """Check if the user is an admin. Will return False if the user is not an admin.
        If the user does not exist, it will raise an UnknowUser exception."""
        if user:
            return user.is_admin
        raise UnknowUser(user)

    @staticmethod
    def UnSubcripeToService(user:UserModel, service:str) -> bool:
        """Remove a service subscription from the user. Will return False if the user does not have the service.
        If the user does not exist, it will raise an UnknowUser exception."""
        if user:
            service_obj = ServiceModel.query.filter_by(names=service).first()
            if not service_obj:
                raise UnknowService(service)
            # user.user_services is a json object that contains all the services that the user has subscribed to check if the service is not false it means that the user has subscribed to it
            if service not in user.user_services or user.user_services[service] == False:
                return False
            services = user.user_services
            services[service] = False
            user.user_services = services
            # remove the user from the service
            service_obj.users.remove(user)
            db.session.commit()
        raise UnknowUser(user)

    @staticmethod
    def getSubServiceUsers(service_name) -> list:
        service_obj = ServiceModel.query.filter_by(names=service_name).first()
        if not service_obj:
            raise UnknowService(service_name)
        return service_obj.users

    @staticmethod
    def addToServiceArgs(User, service_name, value_name, value) -> None:
        if User:
            services = User.user_services
            old_value:dict = services[service_name]
            old_value[value_name] = value
            User.user_services = services
            db.session.commit()
        raise UnknowUser(User)
