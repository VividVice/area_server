from modules.config.config import Config
from modules.config.info import AboutResource
from modules.database.DB import DataBaseOpps as DB
from modules.endpoints.login import Login, Register, RefreshToken, UserInfo
from modules.endpoints.serviceSubscription import Subscripe, Unsubscripe
from modules.endpoints.trello_endpoints.Trello_commands_1 import Trello_Access
# from apscheduler.schedulers.background import BackgroundScheduler
# from trello import Trello, ChatGPT


if __name__ == '__main__':
    config = Config()
    DB.CreateDb()
    config.AddResource(Login, '/login')
    config.AddResource(Register, '/register')
    config.AddResource(AboutResource, '/about.json')
    config.AddResource(Subscripe, '/subscribe')
    config.AddResource(Unsubscripe, '/unsubscribe')
    config.AddResource(RefreshToken, '/refresh')
    config.AddResource(UserInfo, '/me')
    config.AddResource(Trello_Access, '/trello/')
    config.Run()
