import requests
import json
from requests_oauthlib import OAuth1Session
from urllib.parse import urlparse
import time
from dotenv import load_dotenv
import os
import spotipy
from spotipy.oauth2 import SpotifyOAuth
from flask import Flask, request
import random
import string
load_dotenv()

api_trello = os.getenv('API_TRELLO')
api_secret = os.getenv('API_SECRET')
API_TOKEN_TRELLO = ''
global Oauth_token
global Oauth_token_secret


class Spotify:
    def __init__(self):
        self.client_id = os.getenv('SPOTIPY_CLIENT_ID')
        self.client_secret = os.getenv('SPOTIPY_CLIENT_SECRET')
        self.redirect_uri = os.getenv('SPOTIPY_REDIRECT_URI')
        self.scope = "user-read-playback-state playlist-modify-public"

    def login(self):
        state = self.generate_random_string(16)
        scope = "user-read-playback-state"
        auth_manager = SpotifyOAuth(client_id=self.client_id, client_secret=self.client_secret, redirect_uri=self.redirect_uri, scope=scope, state=state)
        auth_url = auth_manager.get_authorize_url()
        auth_url_with_scope = f"{auth_url}&scope={scope}"
        code = request.args.get('code')
        if code:
            token_info = auth_manager.get_access_token(code)
            sp = spotipy.Spotify(auth_manager=auth_manager)
            access_token = token_info['access_token']
            scope = token_info['scope']

    def generate_random_string(self, length):
        letters = string.ascii_lowercase
        return ''.join(random.choice(letters) for i in range(length))

class ChatGPT:
    def handleChatGPT(self, userMessage):
        url = "https://luna-aibot-demo-oai.openai.azure.com/openai/deployments/WidgetFaces/chat/completions?api-version=2023-07-01-preview"

        data = {
            "messages": [
                {"role": "user", "content": "Réponds à cette question :" + userMessage},
            ],
            "max_tokens": 300,
            "temperature": 0.7,
            "frequency_penalty": 0,
            "presence_penalty": 0,
            "top_p": 0.95,
            "stop": None
        }

        headers = {
            "Content-Type": "application/json",
            "api-key": "ba3e6534f94542cb858884cdb2f49b29"
        }

        response = requests.post(url, headers=headers, data=json.dumps(data))
        response_data = response.json()
        botResponse = response_data["choices"][0]["message"]["content"]
        print(botResponse)


class Trello:
    def __init__(self):
        self.has_checkboard = False
        self.Oauth_token = None
        self.initial_board_data = None
        self.Oauth_token_secret = None
        self.has_hap = False
        self.current_board_data = None
        self.logged = False

    def fetch_access_token(self, verifier):
        access_token_url = 'https://trello.com/1/OAuthGetAccessToken'

        trello = OAuth1Session(api_trello, client_secret=api_secret, resource_owner_key=self.Oauth_token, resource_owner_secret=self.Oauth_token_secret)
        response = trello.post(access_token_url, params={'oauth_verifier': verifier})

        if response.status_code == 200:
            access_token_data = dict(x.split('=') for x in response.text.split('&'))
            self.Oauth_token = access_token_data['oauth_token']
            self.Oauth_token_secret = access_token_data['oauth_token_secret']
        else:
            print(f"Error obtaining access token: {response.status_code}")
            print(response.text)

    def get_authorize_url(self):
        request_token_url = 'https://trello.com/1/OAuthGetRequestToken'
        authorization_base_url = 'https://trello.com/1/OAuthAuthorizeToken'
        trello = OAuth1Session(api_trello, client_secret=api_secret)
        trello.fetch_request_token(request_token_url)
        authorization_url = trello.authorization_url(authorization_base_url)
        return authorization_url

    def aunthification_trello(self, verif):

        request_token_url = 'https://trello.com/1/OAuthGetRequestToken'
        authorization_base_url = 'https://trello.com/1/OAuthAuthorizeToken'
        access_token_url = 'https://trello.com/1/OAuthGetAccessToken'

        trello = OAuth1Session(api_trello, client_secret=api_secret)
        trello.fetch_request_token(request_token_url)

        authorization_url = trello.authorization_url(authorization_base_url)
        print(f'Please go to {authorization_url} and authorize access')

        verifier = verif
        # verifier = 'ae67bb4ecf35f1eb2451f82de1736305'
        trello.fetch_access_token(access_token_url, verifier=verifier)

        self.Oauth_token = trello.token.get('oauth_token')
        self.Oauth_token_secret = trello.token.get('oauth_token_secret')
        print("Done!")

        # response = trello.get('https://api.trello.com/1/members/me/boards')
        # if response.status_code == 200:
        #     self.logged = True
        # print(response.text)


    # aunthification_trello()

    def get_board_data(self):
        if self.Oauth_token is None and self.Oauth_token_secret is None:
            self.aunthification_trello()
        trello = OAuth1Session(api_trello,
        client_secret=API_TOKEN_TRELLO,
        resource_owner_key=self.Oauth_token,
        resource_owner_secret=self.Oauth_token_secret)

        response = trello.get('https://api.trello.com/1/members/me/boards')
        if response.status_code == 200:
            boards = response.json()
        else:
            print(f"Error: {response.status_code}")
            print(response.text)
            return

        board_data = {}
        for board in boards:
            board_id = board['id']
            board_name = board['name']
            response = trello.get(f'https://api.trello.com/1/boards/{board_id}/lists')
            lists = response.json()
            board_data[board_id] = {'name': board_name}

            for lst in lists:
                list_id = lst['id']
                list_name = lst['name']
                response = trello.get(f'https://api.trello.com/1/lists/{list_id}/cards')
                cards = response.json()
                card_details = {card['id']: {'name': card['name'], 'desc': card['desc']} for card in cards}
                board_data[board_id][list_id] = {'name': list_name, 'cards': card_details}

        return board_data


    # initial_board_data = get_board_data()
    # print('Initial board data:')
    # print(initial_board_data)

    def check_board_changes(self):

        if self.has_hap == False:
            self.initial_board_data = self.get_board_data()

        self.current_board_data = self.get_board_data()

        for board_id, lists in self.current_board_data.items():
            initial_lists = self.initial_board_data.get(board_id)

            if initial_lists is None:
                print(f'New board detected: {lists["name"]}')
                self.has_checkboard = True
            else:
                self.has_checkboard = False
                for list_id, list_data in lists.items():
                    initial_list_data = initial_lists.get(list_id)

                    if initial_list_data is None:
                        print(f'New list detected on board {lists["name"]}: {list_data["name"]}')
                    elif isinstance(initial_list_data, dict):
                        current_cards = list_data.get('cards', {})
                        initial_cards = initial_list_data.get('cards', {})

                        for card_id, card_data in current_cards.items():
                            initial_card_data = initial_cards.get(card_id)
                            if initial_card_data is None:
                                print(f'New card detected in list {list_data["name"]}: {card_data["name"]}')
                                self.has_checkboard = True
                                #handleChatGPT(card_data["name"])
                            else:
                                if card_data['name'] != initial_card_data['name']:
                                    print(f'Card name changed in list {list_data["name"]}. Old: {initial_card_data["name"]}, New: {card_data["name"]}')
                                if card_data['desc'] != initial_card_data['desc']:
                                    print(f'Card description changed in list {list_data["name"]}. Old: {initial_card_data["desc"]}, New: {card_data["desc"]}')

                        for initial_card_id in initial_cards:
                            if initial_card_id not in current_cards:
                                print(f'Card deleted in list {list_data["name"]}: {initial_cards[initial_card_id]["name"]}')

        # Update initial board data for next check
        self.has_hap = True
        self.initial_board_data = self.current_board_data

# Usage
# while True:
#     trello = Trello()
#     trello.check_board_changes()
#     print('Waiting 0.5 seconds...')
#     time.sleep(0.5)
