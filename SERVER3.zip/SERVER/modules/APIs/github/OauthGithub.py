# Import necessary libraries
import requests
from flask import Flask, request, redirect, session, url_for
from os import getenv
from dotenv import load_dotenv

load_dotenv()
CLIENT_ID = getenv('GITHUB_ID')
CLIENT_SECRET = getenv('GITHUB_SECRET')
# Create a Flask application
app = Flask(__name__)
app.secret_key = getenv('API_SECRET')
# GitHub OAuth URLs
GITHUB_AUTH_URL = 'https://github.com/login/oauth/authorize'
GITHUB_ACCESS_TOKEN_URL = 'https://github.com/login/oauth/access_token'

# Redirect users to GitHub for authentication
@app.route('/login')
def login():
    return redirect(f"{GITHUB_AUTH_URL}?client_id={CLIENT_ID}")

# Handle the GitHub callback and exchange the code for an access token
@app.route('/github-callback')
def github_callback():
    code = request.args.get('code')

    # Request an access token using the code
    response = requests.post(
        'https://github.com/login/oauth/access_token',
        data={
            'client_id': CLIENT_ID,
            'client_secret': CLIENT_SECRET,
            'code': code
        },
        headers={'Accept': 'application/json'}
    )

    if response.status_code == 200:
        data = response.json()
        access_token = data.get('access_token')

        # Now you have the access token, you can use it for making API requests
        # Store the access token or use it as needed in your application

        return f'GitHub OAuth successful! Access token obtained: {access_token}'
    else:
        return 'GitHub OAuth failed.'


# Access a protected resource using the obtained access token
@app.route('/protected')
def protected_resource():
    access_token = session.get('access_token')
    if access_token:
        headers = {'Authorization': f'Bearer {access_token}'}
        response = requests.get('https://api.github.com/user', headers=headers)
        user_data = response.json()
        return f'Hello, {user_data["login"]}! Your GitHub ID is {user_data["id"]}'
    else:
        return 'Access token not found. Please authenticate with GitHub first.'

if __name__ == '__main__':
    app.run(debug=True)