import requests
from os import getenv
from sys import path
path.append('../..')
from modules.config.config import Config
from modules.database.DB import UserModel

class Spotify():
    @staticmethod
    def get_service_info():
        return {
            "name" : "spotify",
            "actions" : [
                {
                    "name" : "new_song",
                    "description" : "A new song is added to a playlist"
                },
                {
                    "name" : "new_playlist",
                    "description" : "A new playlist is created"
                },
                {
                    "name" : "new_album",
                    "description" : "A new album is released"
                },
                {
                    "name" : "new_artist",
                    "description" : "A new artist is followed"
                },
            ],
            "reactions" : [
                {"name": "Create a playlist", "description": "Creates a playlist"},
                {"name": "Add a song", "description": "Adds a song to a playlist"},
                {"name": "Follow an artist", "description": "Follows an artist"},
                {"name": "Save an album", "description": "Saves an album"},
            ]
        }

    @staticmethod
    def create_auth_header(user:UserModel):
        header = {"Authorization": f"Bearer {user.user_services['spotify']['access_token']}"}
        return header

    @staticmethod
    def get_user_playlists(user:UserModel):
        url = "https://api.spotify.com/v1/me/playlists"
        response = requests.get(url, headers=Spotify.create_auth_header(user))
        return response.json()

    @staticmethod
    def get_playlist_tracks(user:UserModel, playlist_id):
        url = f"https://api.spotify.com/v1/playlists/{playlist_id}/tracks"
        response = requests.get(url, headers=Spotify.create_auth_header(user))
        return response.json()

    @staticmethod
    def post_playlist(user:UserModel, playlist_name):
        url = "https://api.spotify.com/v1/me/playlists"
        data = {"name": playlist_name}
        response = requests.post(url, headers=Spotify.create_auth_header(user), json=data)
        return response.json()

    @staticmethod
    def post_track_to_playlist(user:UserModel, playlist_id, track_uri):
        url = f"https://api.spotify.com/v1/playlists/{playlist_id}/tracks"
        data = {"uris": [track_uri]}
        response = requests.post(url, headers=Spotify.create_auth_header(user), json=data)
        return response.json()

    @staticmethod
    def get_user_id(user:UserModel):
        url = "https://api.spotify.com/v1/me"
        response = requests.get(url, headers=Spotify.create_auth_header(user))
        return response.json()["id"]