action_list = [
    {
        "name": "createCard",
        "description": "A new card is created",
        'params': {}
    },
    {
        "name": "createList",
        "description": "A new list is created",
        'params': {}
    },
    {
        "name": "createBoard",
        "description": "A new board is created",
        "params": {}
    },
    {
        "name": "createMember",
        "description": "A new member is added to a board",
        'params': {}
    },
    {
        "name": "updateCard",
        "description": "A card is updated",
        'params': {}
    },
    {
        "name": "updateList",
        "description": "A list is updated",
        'params': {}
    },
    {
        "name": "updateBoard",
        "description": "A board is updated",
        'params': {}
    },
    {
        "name": "updateMember",
        "description": "A member is updated",
        'params': {}
    },
    {
        "name": "deleteCard",
        "description": "A card is deleted",
        'params': {}
    },
    {
        "name": "deleteList",
        "description": "A list is deleted",
        'params': {}
    },
    {
        "name": "deleteBoard",
        "description": "A board is deleted",
        'params': {}
    },
    {
        "name": "deleteMember",
        "description": "A member is deleted",
        'params': {}
    },
]

reactions_list = [
    {
        "name": "createBoard",
        "description": "Creates a board",
        "function_name": "post_board",
        'params': {"name": str}
    },
    {
        "name": "createList",
        "description": "Creates a list",
        "function_name": "post_list",
        'params': {"name": str, "board_name": str}
    },
    {
        "name": "createCard",
        "description": "Creates a card",
        "function_name": "post_card",
        'params': {"name": str, "list_name": str, "msg": str}
    },
    {
        "name": "createMember",
        "description": "Adds a member",
        "function_name": "post_member",
        'params': {"id": str, "board_name": str}
    },
    {
        "name": "deleteBoard",
        "description": "Deletes a board",
        "function_name": "delete_board",
        'params': {"name": str}
    },
    {
        "name": "deleteList",
        "description": "Deletes a list",
        "function_name": "delete_list",
        'params': {"id": str}
    },
    {
        "name": "deleteCard",
        "description": "Deletes a card",
        "function_name": "delete_card",
        'params': {"id": str}
    },
    {
        "name": "deleteMember",
        "description": "Deletes a member",
        "function_name": "delete_member",
        'params': {"id": str, "board_name": str}
    },
    {
        "name": "updateCard",
        "description": "Updates a card",
        "function_name": "post_card",  # TODO: implement this function
        'params': {"id": str, "name": str, "list_name": str, "msg": str}
    },
    {
        "name": "updateList",
        "description": "Updates a list",
        "function_name": "post_list",  # TODO: implement this function
        'params': {"id": str, "name": str}
    },
    {
        "name": "updateBoard",
        "description": "Updates a board",
        "function_name": "post_board",  # TODO: implement this function
        'params': {"id": str, "name": str}
    },
    {
        "name": "updateMember",
        "description": "Updates a member",
        "function_name": "post_member", # TODO: implement this function
        'params': {"id": str, "board_name": str}
    },
]

