from apscheduler.schedulers.background import BackgroundScheduler
from trello import Trello, ChatGPT
from multiprocessing import Process
from flask import Flask, request, render_template, redirect, url_for
import os
from dotenv import load_dotenv

load_dotenv()

api_trello = os.getenv('API_TRELLO')
api_secret = os.getenv('API_SECRET')

app = Flask(__name__)

ChatGPT = ChatGPT()
trel = Trello()

scheduler = BackgroundScheduler()

def check_board_changes():
    if trel.Oauth_token is None:
        return "Trello is not authenticated. Please authenticate first."

    if trel.has_hap == False:
        trel.initial_board_data = trel.get_board_data()

    trel.current_board_data = trel.get_board_data()

    for board_id, lists in trel.current_board_data.items():
        initial_lists = trel.initial_board_data.get(board_id)

        if initial_lists is None:
            print(f'New board detected: {lists["name"]}')
            trel.has_checkboard = True
        else:
            trel.has_checkboard = False
            for list_id, list_data in lists.items():
                initial_list_data = initial_lists.get(list_id)

                if initial_list_data is None:
                    print(f'New list detected on board {lists["name"]}: {list_data["name"]}')
                elif isinstance(initial_list_data, dict):
                    current_cards = list_data.get('cards', {})
                    initial_cards = initial_list_data.get('cards', {})

                    for card_id, card_data in current_cards.items():
                        initial_card_data = initial_cards.get(card_id)
                        if initial_card_data is None:
                            print(f'New card detected in list {list_data["name"]}: {card_data["name"]}')
                            trel.has_checkboard = True
                            ChatGPT.handleChatGPT(card_data["name"])
                        else:
                            if card_data['name'] != initial_card_data['name']:
                                print(f'Card name changed in list {list_data["name"]}. Old: {initial_card_data["name"]}, New: {card_data["name"]}')
                            if card_data['desc'] != initial_card_data['desc']:
                                print(f'Card description changed in list {list_data["name"]}. Old: {initial_card_data["desc"]}, New: {card_data["desc"]}')

                    for initial_card_id in initial_cards:
                        if initial_card_id not in current_cards:
                            print(f'Card deleted in list {list_data["name"]}: {initial_cards[initial_card_id]["name"]}')

    # Update initial board data for next check
    trel.has_hap = True
    trel.initial_board_data = trel.current_board_data

# Schedule the check_board_changes function to run every 5 minutes
scheduler.add_job(check_board_changes, 'interval', seconds=20)
scheduler.start()

@app.route('/')
def index():
    authorization_url = trel.get_authorize_url()
    return render_template('input.html', authorization_url=authorization_url)

@app.route('/oauth_callback', methods=['POST'])
def oauth_callback():
    verification_code = request.form.get('verification_code')

    if verification_code:
        trel.aunthification_trello(verification_code)
        return redirect(url_for('index'))
    else:
        return "Verification code not provided. Authentication failed."

if __name__ == '__main__':
    app.run(debug=True, threaded=True)