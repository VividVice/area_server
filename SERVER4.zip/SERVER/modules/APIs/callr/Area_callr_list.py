action_list = [
    {
        "name" : "call_outbound_hangup",
        "description" : "A call is hangup",
        "params": {}
    },
    {
        "name" : "call_inbound_start",
        "description" : "A call is started",
        "params": {}
    },
    {
        "name" : "call_outbound_start",
        "description" : "A call is started",
        "params": {}
    },
    {
        "name" : "media_recording",
        "description" : "A media is recorded",
        "params": {}
    },
    {
        "name" : "call_inbound_hangup",
        "description" : "A call is hangup",
        "params": {}
    },
    {
        "name" : "billing_credit",
        "description" : "A billing credit",
        "params": {}
    },
    {
        "name" : "send_sms",
        "description" : "A sms is sent",
        "params": {}
    },
    {
        "name" : "did_assigned",
        "description" : "A did is assigned",
        "params": {}
    },
    {
        "name" : "did_unassigned",
        "description" : "A did is unassigned",
        "params": {}
    }
]

reaction_list = [
    {"name": "make_call", "description": "Make a call", "params": {"target": str, "msg": str}},
    {"name": "send_sms", "description": "Send a sms", "params": {"target": str, "msg": str}},
    {"name": "create_media", "description": "Create a media", "params": {"name": str}},
    {"name": "update_media_tts", "description": "Update a media", "params": {"id": str, "msg": str}},
    {"name": "get_list_of_medias", "description": "Get list of medias", "params": {}},
    {"name": "get_quota_status", "description": "Get quota status", "params": {}},
]