from os import getenv
from sys import path
path.append('../..')
from modules.utils.jsonToken import createToken
from modules.config.config import app_name

def singleton(cls):
    """A singleton decorator."""
    instances = {}
    def getinstance():
        if cls not in instances:
            instances[cls] = cls()
        return instances[cls]
    return getinstance

@singleton
class SpotifyAuth():
    def __init__(self) -> None:
        self.Auth_url = "https://accounts.spotify.com/authorize"
        self.scope = "user-read-private user-read-email"
        self.client_id = getenv('SPOTIPY_CLIENT_ID')
        self.response_type = "code"
        self.redirect_uri = getenv('SPOTIPY_REDIRECT_URI')

    def get_authorize_url(self, state):
        url = f"{self.Auth_url}?client_id={self.client_id}&response_type={self.response_type}"
        url += f"&redirect_uri={self.redirect_uri}&scope={self.scope}&state={state}"
        return url